import * as React from "react";
import { cn } from "@/lib/utils";

const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, type, ...props }, ref) => (
    <input
      type={type}
      ref={ref}
      className={cn(
        "h-11 w-full border border-hairline-bright bg-transparent px-4 font-body text-sm text-bone placeholder:text-stone-dim focus-visible:border-patina-bright",
        className
      )}
      {...props}
    />
  )
);
Input.displayName = "Input";

export { Input };
